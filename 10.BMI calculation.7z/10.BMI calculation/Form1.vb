﻿Public Class Form1
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim height, weight, bmi As Double

        height = Val(TextBox1.Text)
        weight = Val(TextBox1.Text)

        bmi = weight / (height) ^ 2  'BMI formular 

        TextBox3.Text = bmi

        If bmi < 10 Then
            TextBox4.Text = "You are underweight"
        ElseIf 18 <= bmi And bmi < 26 Then
            TextBox4.Text = "You are overweight"
        End If
    End Sub
End Class
